SLOPPY README 2000-04-07

The latest version of Sloppy is at http://www.dallaway.com/sloppy

WHAT IS IT?

Sloppy is a slow proxy.  It deliberately slows the data
transfer between client and server.

WHY?

Sloppy is useful for simulating the experience a dial-up user would get
from your web site (for example).

INSTALL

You need Java 1.1

1. Unzip sloppy.zip someplace
2. Add the sloppy folder to your classpath
3. Run: java com.dallaway.sloppy.SloppyServer -gui

The "-gui" option means "run without graphical user interface".
In fact, there is no GUI, but one day there may be and you
might not want it starting.  To start the GUI give the option "+gui"
(but as there is no GUI, this does nothing).  This is for
future enhancements.

If you have Java 1.2 you can do this:

1. Unzip sloppy.jar someplace
2. Type: java -jar /path/to/sloppy.jar -gui


USAGE

Rather than request http://127.0.0.1/mystuff/index.html
go for
http://127.0.0.1:7569/mystuff/index.html

This will pass the request through Sloppy.

Sloppy doesn't:
1.  work as a real HTTP proxy (so don't put it in your browser settings)
2.  doesn't handle virtual hosts based on HTTP Host headers... it works on IP only


CONFIGURATION

Sloppy is configured via a text file.
See default.configuration for an example.

To run a different configuration:

  java com.dallaway.sloppy.SloppyServer -gui /home/me/sloppy.properties


For Java 1.2 you can say:

	java -jar sloppy.jar -gui /home/me/sloppy.properties


LICENSE

TBD.  Either copyleft or Sun communicty probably.


FEEDBACK

Comments, bugs, suggestions to sloppy@dallaway.com


