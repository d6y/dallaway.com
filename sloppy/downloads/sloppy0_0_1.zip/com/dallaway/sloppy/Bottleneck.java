package com.dallaway.sloppy;

import java.util.Hashtable;
import java.util.Date;

/**
 * Mechanism to work out a delay before sending data between client and server.
 * <p>
 *
 * We make use of a staic hash of {@link Usage} objects to record the amount of data
 * sent between a client and a server.  The usage is keyed by client_id (such
 * as IP address).
 * <p>
 *
 * We need to do this because a browser may request multiple files at the same
 * time, and we want to limit overall bandwidth, not just the bandwidth
 * used on each request.
 */
public class Bottleneck
{

  // Hash to usage objects keyed by client_id
  private static Hashtable clients = new Hashtable();

  // This client's id
  private String client_id = null;

  // Usage history
  private Usage usage = null;

  // Our limit in bytes per millisecond
  private double bpm;

  /**
   * Construct a new bottleneck for a give client
   *
   * @param client_id  A way to idnetify a client
   * @param bpm Bytes per millisecond
   */
  public Bottleneck(String client_id, double bpm)
  {
    this.client_id = client_id;
    this.bpm = bpm;
    usage = null;
  }


  /**
   * Delay looking up a client's usage until we have to
   */
  private void getUsage()
  {
    if (usage != null) return;
    synchronized (clients)
    {
      usage = (Usage)clients.get(client_id);
      if (usage == null)
      {
        usage = new Usage();
        clients.put(client_id, usage);
        //System.out.println("Creating "+client_id);
      }
      else
      {
        //System.out.println("Found "+client_id+", total bytes "+usage.getTotalBytes());
      }
    }
  }


  /**
   * Mark a data event.  E.g., client sending data or server sending data.
   * Call this after every receive of data to keep the BPS computation fresh.
   */
  public void mark()
  {
    getUsage();
    usage.mark();
  }

  /**
   * Compute the amount of time to sleep for to keep the client's bandwidth
   * usage inside the BPM measure
   *
   * @return sleep Milliseconds to sleep for; may be -ve indicating no sleep required
   */
  public long restrict(int bytes_read)
  {
      // Keep track of bytes sent
      getUsage();
      usage.increment(bytes_read);
      int total_bytes = usage.getTotalBytes();

      // Keep track of time spend sending those bytes
      long now = new Date().getTime();
      long duration = now - usage.getStartTime();


      long expected_duration = (long)(total_bytes / bpm);

      // If we have arrived her before we are expected, we want to sleep it out
      // so we return the time difference between expected and actual
      return expected_duration - duration;
  }


}



