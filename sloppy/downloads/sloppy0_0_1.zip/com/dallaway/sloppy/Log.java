package com.dallaway.sloppy;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Utility for logging events, errors and debugging information.
 * <p>
 *
 * This version simply writes to STDOUT and STDERR
 * <p>
 * End user events are date stamped.
 * Notices, errors and debugging lines start with a hash (#).
 */
public class Log
{

  // Date to be formated as a common log format
  private SimpleDateFormat sdf = new SimpleDateFormat("[dd/MMM/yyyy HH:mm:ss zzzz]");

  // Set to true for debugging information
  protected final boolean DEBUG = false;

  /**
   * Construct a new default log
   */
  public Log()
  {
  }

  /**
   * Record an event, such as a client request, which should be logged for the end user
   *
   * @param client_id A string identifying the client
   * @param message The message to log.  A time stamp will be included in the output
   */
  public void event(String client, String msg)
  {

    StringBuffer b = new StringBuffer();
    b.append(client); // E.g., IP address
    b.append(" ");
    b.append(sdf.format(new Date())); // Does this need to be syncronized for SDF?
    b.append(" ");
    b.append(msg);

    System.out.println(b.toString());
    b = null; // Help the GC

  }

  /**
   * Write a debugging message
   *
   * @param message The message to write
   */
  public void debug(String msg)
  {
    if (DEBUG) System.out.println("# "+ msg);
  }

  /**
   * Record a notice event, such as service startup
   *
   * @param message The message to write
   */
  public void notice(String msg)
  {
    System.out.println("# " + msg);
  }

  /**
   * Record an error
   *
   * @param message The message to record
   */
  public void error(String msg)
  {
    System.err.println("# "+msg);
  }

  /**
   * Record an error
   *
   * @param message The message to write
   * @param exception Associated exception
   */
  public void error(String msg, Exception ex)
  {
    error(msg+": "+ex.getMessage());
  }

  /**
   * Record an error event
   *
   * @param exception Associated exception
   */
  public void error(Exception ex)
  {
    error(ex.getMessage());
  }


}