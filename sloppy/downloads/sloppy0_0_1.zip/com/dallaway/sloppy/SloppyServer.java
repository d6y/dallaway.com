
package com.dallaway.sloppy;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.IOException;
import java.io.FileInputStream;
import java.util.Properties;

/**
 * Main wrapper class for starting the proxy.
 * <p>
 *
 * Each request creates a new SlowProxyThread to process the request.
 * <p>
 *
 * Latest version of sloppy at http://www.dallaway.com/sloppy.
 * See RELEASE field for this version number.
 * <p>
 *
 * The proxy can be configured via a properties file.  See default.properties
 * for a sample.
 * <p>
 *
 * @see #main
 */
public class SloppyServer
{

  /** Version of this proxy */
  public static String RELEASE = "Sloppy/0.1.0 20000407";

  /** The port we listen on by default */
  public static int DEFAULT_LISTEN_PORT = 7569;

  /** The port we proxy to by default */
  public static int DEFAULT_SEND_PORT = 80;

  /** The IP address we proxy to by default */
  public static String DEFAULT_SEND_HOST = "127.0.0.1";

  protected int listen_port = DEFAULT_LISTEN_PORT;
  protected int send_port = DEFAULT_SEND_PORT;
  protected String  send_host = DEFAULT_SEND_HOST;

  /** Bytes per second */
  protected int bps;

  /** For logging events, errors and so on */
  protected Log log = null;

  /** Is this proxy running? */
  protected boolean running = false;

  // There is no GUI yet, but one day there may be and by default we will start it
  protected boolean start_gui = true;


  /**
   * Create a new proxy server with default settings
   */
  public SloppyServer()
  {
    super();
  }


  /**
   * Set the log instance to use for all events and errors
   *
   * @param logger The instance of a Log for recording events
   */
  public void setLog(Log log)
  {
    this.log = log;
  }


  /**
   * Set the bytes per second to simulate.
   *
   * @param bps Bytes per second
   */
  public void setBPS(int bps)
  {
    this.bps = bps;
  }

  /**
   * Set the port for listening on
   *
   * @param port The port the proxy runs on. Default is 7569
   */
  public void setPort(int port)
  {
    this.listen_port = port;
  }

  /**
   * Set the port where the real server runs
   *
   * @param port  The port to proxy to.  Default is 80
   */
  public void setServerPort(int port)
  {
    this.send_port = port;
  }

  /**
   * Decide if we do or do not start the GUI from main()
   *
   * @param do_start True means the gui will start (default)
   */
  public void startGUI(boolean do_start)
  {
    start_gui = do_start;
  }

  /**
   * Set the host/ip where the real server runs
   *
   * @param host The IP where the real sever runs.  Default 127.0.0.1
   */
  public void setServerHost(String host)
  {
    this.send_host = host;
  }

  /**
   * Start the proxy service
   *
   * @exception IOException Thrown if there was any problem starting the service
   */
  public void go() throws IOException
  {

    if (running) throw new IOException("Server already running");

    log.notice("Starting "+RELEASE);
    log.notice("Running on port "+listen_port);
    log.notice("Proxying to "+send_host+":"+send_port);
    log.notice("BPS "+bps);

    // Lookup the real server address
    InetAddress real_server = null;
    try
    {
      real_server = InetAddress.getByName(send_host);
    }
    catch (UnknownHostException uhx)
    {
      log.error("Cannot start. Bad server address", uhx);
      return;
    }

    // Start listening for proxy requests
    ServerSocket ss = new ServerSocket(listen_port);

    running = true;
    while (running)
    {

      // NB: if performance is an issue we can consider a pool of handler threads here

      try
      {
        // Accept an incoming request...
        Socket request = ss.accept();
        // Hand the request off to a separate thread...
        // NB: we could start threads with different BPS to simulate clients of varying connectivity, perhaps
        SlowProxyThread handler = new SlowProxyThread(log, send_port, real_server, request, bps);
        handler.start();
        // Start listening again...
      }
      catch (IOException iox)
      {
        log.error("Error accepting request", iox);
      }

    }

    log.notice("Shutdown");
  }


  /**
   * Start a proxy server
   *
   * Usage:  Sloppy [+|-gui] [configuration.properties]
   *
   * +gui means start with a graphical user interface (not yet implemented; will be default)
   * -gui means do not start a GUI
   * To override the default settings supply a configuration file.  See default.configuration for an example
   */
  public static void main(String[] args) throws IOException, NumberFormatException
  {

    // Construct the proxy server
    SloppyServer proxy = new SloppyServer();
    proxy.setLog(new Log());

    // Set default options
    proxy.setBPS(3225);

    // Check command line args
    if (args.length != 0)
    {
      readArgs(proxy, args);
    }

    // Start proxying
    proxy.go();

  }

  /**
   * Read configuration properties file and command line args
   *
   * @param server The server to set properties on
   * @param args The command line arguments
   * @exception IOException Thrown if there was a problem reading the properties file
   * @exception NumberFormatException Thrown if there was a problem parsing the contents of the props file
   */
  private static void readArgs(SloppyServer proxy, String[] args) throws IOException, NumberFormatException
  {
    String file = null;  // name of the properties file

    for(int i=0; i<args.length; i++)
    {
      if (args[i].equalsIgnoreCase("+gui") )
      {
        proxy.startGUI(true);
      }
      else if (args[i].equalsIgnoreCase("-gui"))
      {
        proxy.startGUI(false);
      }
      else
      {
        file = args[i];
      }

    } // Endfor

    if (file == null)
    {
      // no properties file supplied
      return;
    }

    Properties props = new Properties();
    props.load(new FileInputStream(file));

    String value = (String)props.get("sloppy.bps");
    if (value != null) proxy.setBPS(Integer.parseInt(value));

    value = (String)props.get("sloppy.port");
    if (value != null) proxy.setPort(Integer.parseInt(value));

    value = (String)props.get("sloppy.serverport");
    if (value != null) proxy.setServerPort(Integer.parseInt(value));

    value = (String)props.get("sloppy.serverhost");
    if (value != null) proxy.setServerHost(value);

  }

}