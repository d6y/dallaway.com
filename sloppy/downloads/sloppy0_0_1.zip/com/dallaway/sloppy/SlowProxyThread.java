package com.dallaway.sloppy;

import java.net.Socket;
import java.net.InetAddress;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


/**
 * All requests are handed off to an instance of this class for co-ordinating
 * sender/receiver communication.
 * <p>
 *
 * We start two threads inside this thread.  The first waits on
 * client requests and pipes the directly to the server.  The second
 * thread listens for server responses and pipes them back to the
 * client.
 * <p>
 *
 * Note that recent browsers use HTTP keep-alive so many HTTP requests
 * could be handled by these threads before they quit.
 * <p>
 *
 * An extra complication is that a web browser will request elements on a page
 * (e.g., GIFs) as separate requests.  To maintain a coherent bandwidth bottleneck
 * we have to record the total bytes sent to a particular client.  This means we
 * need to identify a client.  We use IP address to do this.
 *
 */
public class SlowProxyThread extends Thread
{

  protected Log log;            // For logging
  protected int port;           // server port
  protected InetAddress host;   // server address
  protected Socket request;     // client request
  protected int bps;            // bytes per second

  /** Size of the buffer used for handling client requests */
  protected static int REQUEST_BUFFER_SIZE = 1024;

  /* Size of the buffer used for handling server reponses */
  protected static int RESPONSE_BUFFER_SIZE = 1024 * 8;

  /**
   * Construct a new thread to handle a client request
   *
   * @param log The logger to use
   * @param port The port number of the server to connect to
   * @param host The address of the server to connect to
   * @param request The client request to proxy
   * @param bps Bytes per second
   */
  public SlowProxyThread(Log log, int port, InetAddress host, Socket request, int bps)
  {
    this.log = log;
    this.port = port;
    this.host = host;
    this.request = request;
    this.bps = bps;
  }


  /**
   * Implement a proxy by starting a request forwarding thread and a server
   * relaying thread.
   */
  public void run()
  {

    InputStream client_in=null;
    OutputStream client_out=null;

    InputStream server_in=null;
    OutputStream server_out=null;
    Socket server = null;

    try
    {
      // Communications to client (browser)
      client_in = request.getInputStream();
      client_out = request.getOutputStream();

      // Communcations to server (web server)
      server = new Socket(host, port);
      server_in = server.getInputStream();
      server_out = server.getOutputStream();

      // Work out a identifier for the client.

      /*
        This needs work for the case where we are using the proxy for load testing a server
        E.g., a load simulator will probably be a single machine with a single IP, which
        will loook like a single client to this proxy.  Hmm.
       */
      String client_id = request.getLocalAddress().toString();

      // Pipe the server's reponses to the client
      PassThruThread res = new PassThruThread(server_in, client_out, log, RESPONSE_BUFFER_SIZE, bps, client_id);
      res.start();

      // Pipe the client's request to the server
      PassThruThread req = new PassThruThread(client_in, server_out, log, REQUEST_BUFFER_SIZE, bps, client_id);
      req.start();

      // Wait for the above threads to quit
      try
      {
        req.join();
      }
      catch (InterruptedException ie1)
      {
        log.error("While wainting for req to close", ie1);
      }

      try
      {
        res.join();
      }
      catch (InterruptedException ie2)
      {
        log.error("While wainting for res to close", ie2);
      }

      // We're done
      log.debug("Pass thru done, now tearing down");

    }
    catch (IOException iox)
    {
      // Likey to be "Connection refused" if the server is dead
      log.error("Proxy failed (is the server runnning?)", iox);
    }
    finally
    {

      // Close down all the connections no matter what happens

      try
      {
        if (client_in != null) client_in.close();
      }
      catch (IOException iox1)
      {
        log.error("While closing client in", iox1);
      }

      try
      {
        if (client_out != null) client_out.close();
      }
      catch (IOException iox2)
      {
        log.error("While closing client out", iox2);
      }

      try
      {
        if (server_out != null) server_out.close();
      }
      catch (IOException iox3)
      {
        log.error("While closing server out", iox3);
      }

      try
      {
        if (server_in != null) server_in.close();
      }
      catch (IOException iox4)
      {
        log.error("While closing server in", iox4);
      }

      try
      {
        if (server != null) server.close();
      }
      catch (IOException iox5)
      {
        log.error("While closing server", iox5);
      }


    }

    log.debug("REQUEST DONE");

  }

}