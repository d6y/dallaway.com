package com.dallaway.sloppy;

import java.util.Date;

/**
 * Records the bandwidth usage for a given client.
 * <p>
 *
 * Note that if a user does not make a request for 5 seconds, this
 * data is considered stale and is reset.  We do this because
 * we use timestamp of first request and total bytes transferred
 * as measures to keep BPS low.  If a user goes away for a few
 * hours, it may suddenly look as if they have had very
 * low bandwidth usage (= bytes / total time).   If the user
 * is doing nothing, bytes is constant and total time increases
 * until they have effectively unlimited bandwidth.  So we reset
 * bytes and total time if the user goes quite for 5 seconds or longer.
 */
public class Usage
{

  long start_time = -1; // Time stamp of the first request
  int total_bytes = 0;  // Total bytes exchanged since the start time

  long last_mark = -1; // last time mark() was called

  // Number of milliseconds between requests until we consider
  // our data to be stale
  private static long MIN_MARK_INTERVAL = 1000 * 5;

  public Usage()
  {
  }

  /**
   * Note that the client has exchanged some data
   *
   * @param bytes The number of bytes exchanged
   */
  public void increment(int n)
  {
    total_bytes += n;
  }

  /**
   * Note that a data exchange event has occured
   */
  public void mark()
  {

    long now =  new Date().getTime();

    if (start_time == -1) start_time = now;

    if (last_mark == -1)
    {
      last_mark = now;
      return;
    }

    if (now - last_mark >= MIN_MARK_INTERVAL)
    {
      // Reset
      start_time = now;
      total_bytes = 0;
    }

    last_mark = now;

  }

  /**
   * @return start_time The time of the first data exchange event
   */
  public long getStartTime()
  {
    return start_time;
  }

  /**
   * @return total_bytes Total bytes exchanged to date
   */
  public int getTotalBytes()
  {
    return total_bytes;
  }
}