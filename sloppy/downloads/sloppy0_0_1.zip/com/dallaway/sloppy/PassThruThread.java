package com.dallaway.sloppy;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Date;

/**
 * A pipe for punting data from a sender to a receiver.  In this
 * class we implement a delay for simulating slow network connections.
 * <p>
 *
 * We don't implement latency here -- we just do transmission rate
 *
 */
public class PassThruThread extends Thread
{

  InputStream in=null;    // Data source
  OutputStream out=null;  // Data sink
  Log log = null;         // For logging
  int buffer_size;        // in bytes
  double bpm;             // bytes per millisecond
  String client_id;       // String to identify the client

  /**
   * Construct a new pipe.
   *
   * @param in The input stream to listen on
   * @param out The output stream to write to
   * @param log The logging instance to use
   * @param buffer_size The size of the buffer, in bytes, for holding sender's data
   * @param bps Bytes per second
   * @param client_id String identiying this client.  Probably IP address
   */
  public PassThruThread(InputStream in, OutputStream out, Log log, int buffer_size, int bps, String client_id)
  {
    this.in = in;
    this.out = out;
    this.log = log;
    this.buffer_size = buffer_size;
    // To save time later we conver to milliseconds
    this.bpm = ((double)bps) / 1000.0;
    this.client_id = client_id;

  }

  /**
   * Start passing data from sender to receiver
   */
  public void run()
  {

    // Construct a bottleneck to limit this user to a specific set of bytes per millisecond
    Bottleneck bottleneck = new Bottleneck(client_id, bpm);

    byte[] buffer = new byte[buffer_size];

    // Have we logged the first line of the sender's data yet?
    boolean first_line_logged = false;

    try
    {
      // Read all of the sender's message...
      while (true)
      {
        int num_read = in.read(buffer);
        bottleneck.mark(); // mark an event

        if (num_read == -1) break;  // end of data

        // Send data on to the receiver, after an appropriate delay

        long delay = bottleneck.restrict(num_read);
        if (delay > 0)
        {
          try
          {
            log.debug(getName()+" sleeping "+delay);
            sleep(delay);
          }
          catch (InterruptedException ix)
          {
            log.error(ix);
          }
        }

        out.write(buffer, 0 , num_read);
        out.flush(); // is this needed?

        if (first_line_logged == false && num_read > 0)
        {
          // KEEP-ALIVE: we will only log the first request if we receive
          // multiple requests via http keep alive
          first_line_logged = true;
          String msg = new String(buffer,0,num_read);
          int nl = msg.indexOf("\n");
          if (nl != -1) msg = msg.substring(0, nl);
          log.event(client_id,msg);
        }

        yield();

      }

    }
    catch (IOException iox)
    {
      // Very likely to be "Connection reset by peer" when the browser closes
      log.error(iox);
    }

    // log.notice("DONE");

  }


}