package com.dallaway.jsptest;

import java.net.URL;

/**
 * Common functionality across both GET and POST requests.
 * 
 * @author		$Author$
 * @version	$Revision$ $Date$
 */
public abstract class BaseRequest
{
	
	// The base URL to request.  May or may not include GET parameters.
	protected URL url;

	// The port form the URL.	
	int port = -1;


	protected BaseRequest(URL url)
	{
		this.url = url;
		this.port = url.getPort();	
	}
	

	/**
	 * @return	secure	True if the request is for HTTPs.
	 */
	public boolean isSecure()
	{
   		String protocol = url.getProtocol();
		return "https".equalsIgnoreCase(protocol);
	}
	
	
	public String getHost()
	{
	  return url.getHost();	
	}

	/**
	 * Clean up the port, using the correct default port number if
	 * no port was excplitily supplied in the request URL.
	 * 
	 * @return	port	The specified port number, or the appropriate
	 * 					default port for the request if no port was
	 * 					specified.
	 */
	public int getPort()
	{
  		// Port is specified, so use it.
  		if (port > 0)
  			return port;
  	
  		// Default port for HTTPS is 443
  		if (isSecure())
  			port = 443;
  		else
  			port = 80;
  		
  		return port;
	}

	
}

