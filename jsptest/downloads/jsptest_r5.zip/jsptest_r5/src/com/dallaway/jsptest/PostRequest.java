package com.dallaway.jsptest;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Hashtable;

/**
 * 
 * @author		$Author$
 * @version	$Revision$ $Date$
 */
public class PostRequest extends BaseRequest implements Request
{
	
	// For building up the request parameters.	
	private StringBuffer params = new StringBuffer();
	
	private String httpVersion;
	
	public PostRequest(URL url, String httpVersion)
	{
		super(url);	
		this.httpVersion = httpVersion;
	}
	
	
	public void addParameter(String name, String value)
	{
		if (params.length() > 0)
			params.append("&");
		
		params.append(name);
		params.append("=");
		params.append(URLEncoder.encode(value));		
	}
	
	
	public String getRequestLine()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("POST ");
		buf.append(url.getFile());
		buf.append(" ");
		buf.append(httpVersion);
		return buf.toString();
	}
	
	public Hashtable getHeaders()
	{
		Hashtable headers = new Hashtable();
		headers.put("Content-type", "application/x-www-form-urlencoded");
		headers.put("Content-length", Integer.toString(params.length()));
	
		return headers;	
	}
	

	public String getMessageBody()
	{
		return params.toString();
	}
	
	
}

