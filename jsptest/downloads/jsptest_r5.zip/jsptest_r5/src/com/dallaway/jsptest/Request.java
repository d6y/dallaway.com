package com.dallaway.jsptest;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Hashtable;

/**
 * A request is something that a Session can send to receive
 * a response.
 *
 * @author		richard@dallaway.com
 * @version	$Revision$ $Date$
 */
public interface Request
{
	
	/**
	 * Add a parameter to the request. You can add many parameters
	 * with the same name: they will all be sent as part of the request. 
	 * 
	 * @param	name	The name of the parameter.
	 * @param	value	The value of the parameter.
	 */
	public	void addParameter(String name, String value);
	
	
	/**
	 * @return	secure	True if the connection is a secure connection
	 * 					(e.g., https).  False otherwise.
	 */
	public boolean isSecure();
	
	
	/**
	 * @return	port	The port number for this request.
	 */
	public int getPort();
	
	/**
	 * @return	host	The host to connect to for this request.
	 */
	public String getHost();


	
	/**
	 * @return	header	Generate the RFC 2616 header for this request, such
	 * 					as "GET /foo.html HTTP/1.0".
	 */
	public String getRequestLine();


	/**
	 * @return	headers	Extra headers for this request. Can be null.
	 */
	public Hashtable getHeaders();
	
	
	/**
	 * @return	body	The request message body. Can be null.
	 */
	public String getMessageBody();	
	
}

