package com.dallaway.jsptest;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Hashtable;

/**
 * 
 * @author		$Author$
 * @version	$Revision$ $Date$
 */
public class GetRequest extends BaseRequest implements Request
{
	
	// Buffer for building up the request string.	
	private StringBuffer requestBuffer = new StringBuffer();
	private boolean hasParams = false;
	
	private String httpVersion;
	

	public GetRequest(URL url, String httpVersion)
	{
		super(url);	
		this.httpVersion = httpVersion;
	
		requestBuffer.append(url.getFile());
		
		// Do we have any parameters?
		hasParams = url.getFile().indexOf("?") != -1;		
	}
	
	
	public void addParameter(String name, String value)
	{
		requestBuffer.append( hasParams ? "&" : "?" );
		
		requestBuffer.append(name);
		requestBuffer.append("=");
		requestBuffer.append(URLEncoder.encode(value));
	
		hasParams = true;	
	}
	
	
	public String getRequestLine()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("GET ");
		buf.append(requestBuffer.toString());
		buf.append(" ");
		buf.append(httpVersion);
		return buf.toString();
	}
	
	public Hashtable getHeaders()
	{
		return null;	
	}
	
	public String getMessageBody()
	{
		return null;
	}
	
	
	
	
}

