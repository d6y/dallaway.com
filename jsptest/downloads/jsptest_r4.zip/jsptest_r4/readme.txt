README.TXT

JSP TEST is a collection of Java classes to help you test JSPs automatically.
It is intended for use with a unit testing framework such as JUnit.

See http://www.dallaway.com/jsptest/ for details and the latest release.

This is release 4, 3 December 2001,

See the apidoc/, Example1.txt and JSPTestTest.txt for example usage.

Files:

src/		Java source code
jsptest.jar	Compiled classes.
test.war	The test pages used by JSPTestTest	
wwwtest/	Simple test pages, used by JSPTestTest.java
apidoc/		Java doc
lib/		Third party libraries used by jsptest
build.xml	The Ant build file.
readme.txt	This file.

This product includes code licensed from RSA Data Security.  Please
see the lib/jsseLICENCE.txt for details.

To run a test using JPSTest you need to include the JSSE libraries. I.e.,
java -cp jsptest.jar;lib/jsse.jar;lib/jcert.jar;lib/jnet.jar ...


To run JSPTestTest (the unit test for JSPTest), you also need junit.jar 
(version 3.7)

CHANGES

Release 4, 3 December 2001:

- Added HTTPS support using JSSE.


Release 3, 16 November 2001:

- Bug fix for testing pages on the default port (80).  Report by Vinoth Prabakaran.
- In preparation for JDK 1.4, the code has moved to using JUnit 3.7
- Addition of test.war to make it easier to set up the JSPTestTest requirements.
- build.xml upgraded to run with Ant 1.4.  General clean up of build process.




