README.TXT

Release: 2

See jsptest.html for information.

Files:

src/		Java source code
bin/		Binary classes
wwwtest/	Simple test pages, used by JSPTestTest.java
jsptest.jar	The test classes, ready to use.
apidoc/		Java doc
jsptest.jpr	JBuilder 3.5 project file.
build.xml	The Ant build file.

Note: to rebuild the project you will need JUnit.jar.
You can get JUnit from: http://xprogramming.com/software.htm

You can find the latest version of jsp test at:
http://www.dallaway.com/jsptest


