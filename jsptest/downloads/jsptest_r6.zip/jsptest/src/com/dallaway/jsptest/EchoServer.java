package com.dallaway.jsptest;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Starts up a server which simply echos to STDOUT anything it receives.
 *
 * <p>
 * This is useful for debugging communications to servers where you want
 * to be sure you're sending the right things.  Designed to work
 * with HTTP, SMTP and similar text protocols.
 *
 * @author  $Author: richard $
 * @version $Revision: 1.3 $  $Date: 2001/11/16 10:21:20 $
 */
public class EchoServer
{

  /** Buffer for reading. */
  private static final int BUFSIZ = 1024;

  /** Port to listen on. */
  private int port = 80;

  /**
   * Construct a new echoing server on the given port.
   *
   * @param port Port to listen on.
   */
  public EchoServer(int port)
  {
    this.port = port;
  }

  /**
   * Start listening forever.
   *
   * @throws IOException Thrown if there were any network errors.
   */
  public void go() throws IOException
  {

    notice("Starting on: "+port);

    // Start listening for requests
    ServerSocket ss = new ServerSocket(port);

    while (true)
    {

      try
      {
        // Accept an incoming request...
        Socket request = ss.accept();
        // Note that we don't bother firing off a new thread, as this is just
        // intended for debugging single requests
        handle(request);
        // Start listening again...
      }
      catch (IOException iox)
      {
        error("Error accepting request", iox);
      }

    }


  }


  /**
   * Hande a single request by echoing to stdout.
   *
   * @param request The socket request to read and echo.
   * @throws IOException Thrown if there was any errors reading the request.
   */
  private void handle (Socket request) throws IOException
  {
    InputStream in = request.getInputStream();
    byte[] buffer = new byte[BUFSIZ];

      while (true)
      {
        int numRead = in.read(buffer);

        if (numRead == -1) 
        {
            break;  // end of data
        }

        output(new String(buffer, 0 , numRead));

      }
  }


  /**
   * Output the request received to stdout.
   *
   * @param msg The message to output.
   */
  public void output(String msg)
  {
    System.out.println(msg);
  }

  /**
   * Log an error.
   * 
   * @param msg The message to output.
   * @param x The associated exception.
   */
  private void error(String msg, Exception x)
  {
    System.err.println(msg+": "+x.getMessage());
  }

  /**
   * Log a notice.
   * 
   * @param msg The message to output.
   */
  private void notice(String msg)
  {
    System.out.println(msg);
  }

  /**
   * Start an echo service.
   * 
   * @param args Usage: echoServer port-num
   * @throws IOException Thrown if there was any problem.
   */
  public static void main(String[] args) throws IOException
  {

    if (args.length != 1)
    {
      System.err.println("Usage: EchoServer port-num");
      System.exit(0);
    }

    EchoServer echo = new EchoServer(Integer.parseInt(args[0]));

    echo.go();
  }


}

