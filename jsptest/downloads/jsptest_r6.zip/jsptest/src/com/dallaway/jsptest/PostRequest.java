package com.dallaway.jsptest;

import java.net.URL;
import java.util.Hashtable;

import org.apache.commons.httpclient.methods.PostMethod;

/**
 * Implementation of a Request where the method is POST.
 * 
 * @author $Author: richard $
 * @version	$Revision: 1.2 $ $Date: 2002/01/11 11:33:44 $
 */
public class PostRequest extends BaseRequest implements Request
{
	
    /** The HTTP version to send. */
	private String httpVersion;
	
    /** The method used for the POST. */
    private PostMethod method;
      
    /** For building up a string of param arguments. */
    private StringBuffer params = new StringBuffer();
      
    /**
     * Construct a new POST request/
     * 
     * @param url The URL to request.
     * @param httpVersion The HTTP version to send.
     */
	public PostRequest(URL url, String httpVersion)
	{
		super(url);	
		this.httpVersion = httpVersion;

        method = new PostMethod(url.getPath());        
        method.setHttp11(httpVersion.indexOf("1.1") != -1);
        setMethod(method);
	}
	
    
    
	/**
     * @see Request#addParameter(String, String)
     */
	public void addParameter(String name, String value)
	{
        method.addParameter(name, value);
        
        // We also do this just for backward compatability with
        // JSPTest release 5:
        if (params.length() > 0)
        {
            params.append("&");
        }
        
        params.append(name);
        params.append("=");
        params.append(urlEncode(value));    
        
	}



	
	
    /**
     * @see Request#getRequestLine()
     * @deprecated Obsolete.
     */
	public String getRequestLine()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("POST ");
		buf.append(getURL().getFile());
		buf.append(" ");
		buf.append(httpVersion);
		return buf.toString();
	}
	
    /**
     * @see com.dallaway.jsptest.Request#getHeaders()
     * @deprecated Obsolete.
     */
	public Hashtable getHeaders()
	{
		Hashtable headers = new Hashtable();
		headers.put("Content-type", "application/x-www-form-urlencoded");
		headers.put("Content-length", Integer.toString(params.length()));
	
		return headers;	
	}
	
    /**
     * @see Request#getMessageBody()
     * @deprecated Obsolete - no longer used internally when making requests.
     */
	public String getMessageBody()
	{
		return params.toString();
	}
	
	
}

