package com.dallaway.jsptest;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.StatusLine;

/**
 * Container for the results from processing a HTTP request.
 *
 * @author  $Author: richard $
 * @version $Revision: 1.4 $  $Date: 2001/11/16 14:17:58 $
 */
public class Response
{

  /** The body of the response. */
  private String body;
  
  /** The HTTP status code. */
  private int status = -1; 
  
  /** Container for the headers. */
  private Hashtable headers = new Hashtable();

  /**
   * Construct a new response from a HTTP request.
   *
   * @param body    The object containg the body of the response.
   * @param headers Http headers.
   * @param statusLine  The status line.
   *
   */
  public Response(String body, Hashtable headers, String statusLine)
  {
    this.body = body;
    this.headers = headers;
   
    if (statusLine != null)
    {
        try
        {
             this.status = new StatusLine(statusLine).getStatusCode();
        }
        catch (HttpException e)
        {
            // Ah well, we tried.
            System.err.println(e);
        }
    }
  }

  /**
   * Construct a new container for the HTTP response.  This is
   * now the prefered version of the constructor.
   * 
   * @param body The body of the response.
   * @param clientHeaders The HTTP headers.
   * @param status The HTTP status code.
   */
  public Response(String body, Header[] clientHeaders, int status)
  {
    this.body = body;
    this.status = status;
    
    // This looks insane, but it keeps compatability with release 5 of JSPTest:
    for(int i=0, n=clientHeaders.length; i<n; i++)
    {
        headers.put( clientHeaders[i].getName(), clientHeaders[i].getValue())  ;
    }
    
  }


  /**
   * Get the text body of the response.
   *
   * @return body The string body (e.g., HTML) for the response.
   */
  public String getBody()
  {
    return body;
  }

  /**
   * Get the HTTP status code for this request.
   *
   * @return code The HTTP status code, or -1 if the code is unavailable (e.g., cannot
   * be parsed from the server response).
   */
  public int getStatusCode()
  {
   return status;
  }



  /**
   * Get a HTTP header.  Examples include: status, Date, Server, Last-Modified,
   * Content-Length, Content-Type, Set-Cookie.
   *
   * @param name    The name of the header to look up.
   * @return value The values associated with the header, or null of the header was not found.
   */
  public String getHeader(String name)
  {
    return (String)headers.get(name);
  }


  /**
   * A list of the headers names read back as part of the response.
   * 
   * @return List of header names.  Possibly zero length, but never null.
   */
  public synchronized String[] getHeaderNames()
  {
  	int n = headers.size();
	String[] toRet = new String[n];	  	
	
	Enumeration e = headers.keys();
	int i = 0;
	while (e.hasMoreElements())
	{
		toRet[i++] = (String)e.nextElement();
	}
	
	return toRet;
  }


  /**
   * From the body, get the text from between a start and end string.
   *
   * <p>
   * This is a convieniece method to help you find particular
   * text on a page.
   *
   * <p>
   * E.g., if you page contains the text:
   * "Reason for error: something bad happened."
   * You can extract the reason with:
   *   String reason = request.extractBetween("Reason for error: ", ".");
   *
   *
   * <p>
   * @param   start The start text to search for,
   * @param   end The text that ends the item you're looking for.
   *
   * @return  The text between the end of the start text and the start
   * of the end text.  Got that?  Null if no match was found. If more than one
   * match is found, only the first is returned.
   *
   * @see #getBetweens
   */
   public String getBetween(String start, String end)
   {

    String[] betweens = getBetweens(start, end);

    if (betweens == null || betweens.length == 0)
    {
         return null;
    }
    
    return betweens[0];

   }

   /**
    * From the body, extract all occurances of the text between a start
    * and end string.
    * <p>
    *
    * @see #getBetween for details and if you're only looking for one match.
    *
    * @param  start The start text to search for,
    * @param  end The text that ends the item you're looking for.
    *
    * @return Array containing the text between the end of the start text
    * and the start of the end text for all occurances of the start text. Null
    * if start text or end text is null or if there is no body text to search.
    * Can be a zero length array.
    *
    */
   public String[] getBetweens(String start, String end)
   {

      // Sanity checks first:
      if (body == null || start == null || end == null || "".equals(end) || "".equals(start))
      {
        return null;
      }

      // Temporary storage for anything we find.
      Vector matches = new Vector();

      // Surely the compiler would do this for me anyway...
      int startTextLength = start.length();
      int endTextLength = end.length();


      int startPoint = 0;      // Where to start searching from inside body
      int startMatchPoint;    // Where the start text matches
      int endMatchPoint;      // where the end text matches inside body

      while (true)
      {

        // Find the start_text
        startMatchPoint = body.indexOf(start, startPoint);
        if (startMatchPoint == -1) 
        {
            break;
        }

        startMatchPoint += startTextLength; // Skip past the start_text itself

        // Find the end_text
        endMatchPoint = body.indexOf(end, startMatchPoint);
        if (endMatchPoint == -1) 
        {
            break;
        }

        // If we get here, we've got a match inside body

        matches.addElement( body.substring(startMatchPoint, endMatchPoint) );

        // Move on for the next search

        startPoint = endMatchPoint + endTextLength;

      } // endwhile


      //  Convert results to a string array
      int n = matches.size();
      String[] toRet = new String[n];
      for(int i=0; i<n; i++)
      {
        toRet[i] = (String)matches.elementAt(i) ;
      }


      return toRet;
   }


}