package com.dallaway.jsptest;

import java.util.Hashtable;

import org.apache.commons.httpclient.HttpMethod;

/**
 * A request is something that a Session can send to receive
 * a response.
 *
 * @author richard@dallaway.com
 * @version	$Revision: 1.1 $ $Date: 2002/01/11 11:29:34 $
 */
public interface Request
{
	
	/**
	 * Add a parameter to the request. You can add many parameters
	 * with the same name: they will all be sent as part of the request. 
	 * 
	 * @param	name	The name of the parameter.
	 * @param	value	The value of the parameter.
	 */
	void addParameter(String name, String value);
	
    /**
     * @return The Apache HTTP Client method.
     */
    HttpMethod getMethod();    
    
	
	/**
	 * @return	True if the connection is a secure connection (e.g., https).  False otherwise.
	 */
	 boolean isSecure();
	
	
	/**
	 * @return	The port number for this request.
	 */
	 int getPort();
	
	/**
	 * @return	The host to connect to for this request.
	 */
	String getHost();


	
	/**
	 * @return	Generate the RFC 2616 header for this request, such	as "GET /foo.html HTTP/1.0".
     * @deprecated No longer used internally.
	 */
	String getRequestLine();


	/**
	 * @return	Extra headers for this request. Can be null.
     * @deprecated No longer used when making requests.
	 */
	Hashtable getHeaders();
	
	
	/**
	 * @return	The request message body. Can be null.
     * @deprecated No longer used when making a request, so of no value any more.
	 */
	String getMessageBody();	
	
 
    
}

