package com.dallaway.jsptest;

import java.net.URL;
import java.net.URLEncoder;

import org.apache.commons.httpclient.HttpMethod;

/**
 * Common functionality across both GET and POST requests.
 * 
 * @author $Author: richard $
 * @version	$Revision: 1.2 $ $Date: 2002/01/11 11:33:32 $
 */
public abstract class BaseRequest
{
	
	/** The base URL to request.  May or may not include GET parameters. */
	private URL url;

	/** The port from the URL.	*/
	private int port = -1;

    /** The Method for Apache's HTTP client. */
    private HttpMethod method;


    /** Construct a new request for the given URL.
     * @param url The URL to request.
     */
	protected BaseRequest(URL url)
	{
		this.url = url;
		this.port = url.getPort();	
	}
	

	/**
	 * @return	True if the request is for HTTPs.
	 */
	public boolean isSecure()
	{
   		String protocol = url.getProtocol();
		return "https".equalsIgnoreCase(protocol);
	}
	

	/**
	 * @return	The host to connect to.
	 */	
	public String getHost()
	{
	  return url.getHost();	
	}

	/**
	 * Clean up the port, using the correct default port number if
	 * no port was excplitily supplied in the request URL.
	 * 
	 * @return	The specified port number, or the appropriate
	 * 			default port for the request if no port was
	 * 			specified.
	 */
	public int getPort()
	{
  		// Port is specified, so use it.
  		if (port > 0)
        {
  			return port;
        }
  	
  		// Default port for HTTPS is 443
  		if (isSecure())
        {
  			port = 443;
        }
  		else
        {
  			port = 80;
        }
  		
  		return port;
	}

	
    /**
     * @return The URL being requested.
     */
    protected URL getURL()
    {
        return this.url;   
    }
 
     /**
     * URL encode a string.
     * @param value The value to encode.
     * @return The encoded value
     */
    protected String urlEncode(String value)
    {
        return URLEncoder.encode(value);
    }
    
    /**
     * @see Request#getMethod()
     */
    public HttpMethod getMethod()
    {
        return method;
    }

    /**
     * Sets the Apache HTTP method.
     * @param method The method to set.
     */
    protected void setMethod(HttpMethod method)
    {
        this.method = method;
    }

}

