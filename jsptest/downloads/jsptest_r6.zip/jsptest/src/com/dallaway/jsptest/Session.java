package com.dallaway.jsptest;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.Security;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpState;

/**
 * HTTP session implementation for managing client state and firing off HTTP requests.
 *
 * <p>
 * This session is your starting point for all JSP testing.  Create
 * a session, and from this you can make requests and query cookies.
 * <p>
 * 
 * Set HTTP headers in the session using <code>setHeader()</code>.  By default the header
 * "User-Agent" is already set to IE5.0 for NT.  You can change this
 * with a call to: 
 * <code>session.setHeader("User-Agent", "Mozilla/5.0 (Windows; U; WinNT4.0; en-US; m14) Gecko/20000419")</code>.
 * <p>
 * Other headers you might want to set and suggested values:
 * <br>
 * <table border="1">
 * <tr><th>Header</th><th>Example values</th></tr>
 * <tr><td>Accept</td><td>*&0#047;* or image/gif, image/jpeg</td></tr>
 * <tr><td>Accept-Language</td><td>en-us</td></tr>
 * <tr><td>Authorization</td><td>BASIC d2vjkkjdfKJHGS873H=</td></tr>
 * <tr><td>Referer</td><td>http://foo.baz/index.html</td></tr>
 * </table>
 * <br>
 * ...and any of headers you like, but note that Set-Cookie is handled
 * by the addCookie() method.
 * 
 * <p>This is now just a wrapper to Apache's HTTP Client code.</p>
 *
 * @author  $Author: richard $
 * @version $Revision: 1.5 $  $Date: 2002/01/11 11:10:01 $
 */
public class Session
{

    /** The client making the request. */
    private HttpClient client;

    /** The state of the client (i.e., for cookies). */
    private HttpState state;
  
    /** Headers sent with every request. */
    private Hashtable headers;
 
    /** Cookies that are added to all requests, regardless of domain. */
    private Vector cookies;
 
    /** handy constant for IE 5 on NT. */
    public static final String UA_IE_50_NT = "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)";

    /** Handy constant for Mozilla on NT. */
    public static final String UA_MOZ_50_NT = "Mozilla/5.0 (Windows; U; WinNT4.0; en-US; m14) Gecko/20000419";

    /** The HTTP Version header to send. */
    private String httpVersion;

  /**
   * Create a new empty session, with default user agent of IE5 (NT).
   */
  public Session()
  {
    reset();
  }

  /**
   * Clear the session.  This removes all client-side state information.
   */
  public void reset()
  {
    client = new HttpClient();
    state = new HttpState();
    client.setState(state);
   
    headers = new Hashtable();
    cookies = new Vector();
       
    setHeader("User-Agent", UA_IE_50_NT);
    setHTTPVersion("HTTP/1.1");
    
   System.setProperty("java.protocol.handler.pkgs","com.sun.net.ssl.internal.www.protocol");
   Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
   
  }

  /**
   * Set the user agent string to send to the server.
   *
   * @param name The header to send (do not include trailing colon).
   * @param value The value to associate with the header.
   */
  public void setHeader(String name, String value)
  {
    headers.put(name, value);
  }

  /**
   * The list of active cookies.
   *
   * @return cookies An array of Cookie objects.
   */
  public synchronized com.dallaway.jsptest.Cookie[] getCookies()
  {
	Cookie[] cookies = state.getCookies();
    int n = cookies.length;
    
    if (n == 0)
    {
        // Nothing in the state yet, so try the global cookies list
        n = this.cookies.size();
        com.dallaway.jsptest.Cookie[] toRet = new com.dallaway.jsptest.Cookie[n];
        for(int i=0; i<n; i++)
        {
            toRet[i] = (com.dallaway.jsptest.Cookie)this.cookies.get(i);
        }
        return toRet;
    }
    
    // Some cookies exist in the state, so look there:
    com.dallaway.jsptest.Cookie[] toRet = new com.dallaway.jsptest.Cookie[n];

    for(int i=0; i<n; i++)
    {
        toRet[i] = new com.dallaway.jsptest.Cookie( cookies[i].getName(), cookies[i].getValue() );
    }

    return toRet;
  }

  /**
   * Add a cookie to this session.
   * <p>
   *
   * @param cookie The cookie to add to the session.
   */
  public synchronized void addCookie(com.dallaway.jsptest.Cookie cookie)
  {
    // Remove duplicate named cookie:
    Enumeration e = cookies.elements();
    while (e.hasMoreElements())
    {
        com.dallaway.jsptest.Cookie c = (com.dallaway.jsptest.Cookie)e.nextElement();
        if (c.getName().equals(cookie.getName()))
        {
            cookies.remove(c);
            break;
        }    
    }

    cookies.add(cookie);
  }

  /**
   * Look up a single cookie value by name.
   *
   * @param name The name of the cookie to look up.
   * @return The value associated with the cookie, or null if the cookie was not found.
   */
  public synchronized String getCookieValue(String name)
  {

    com.dallaway.jsptest.Cookie[] cookies = getCookies();

   
    for(int i=0, n=cookies.length; i<n; i++)
    {
        com.dallaway.jsptest.Cookie c = cookies[i];
        if (name.equals(c.getName()))
        {
            return c.getValue();
        }
    }

     return null;
  }


    /**
     * Send a request.
     * @param request The request to send.
     * @return The response.
     * @throws MalformedURLException Thrown if the URL requested is bad.
     * @throws IOException Thrown if there was a problem communicating with the server.
     */
   public Response send(Request request) throws MalformedURLException, IOException
   {
        HostConfiguration config = new HostConfiguration();
        config.setHost(request.getHost(), request.getPort(), request.isSecure() ? "https" : "http" );
        client.setHostConfiguration(config);

        HttpMethod method = request.getMethod();
        
        // Add global headers:
        Enumeration e = headers.keys();
        while (e.hasMoreElements())
        {
            String name = (String)e.nextElement();
            if (method.getRequestHeader(name) == null)
            {
                method.setRequestHeader(name, (String)headers.get(name));
            }
        }
        
        // Add global cookies:
        for(int i=0, n=cookies.size(); i<n; i++)
        {
            com.dallaway.jsptest.Cookie cookie = (com.dallaway.jsptest.Cookie)cookies.get(i);
            if (!cookieAlreadySet(cookie.getName()))
            {
                System.out.println("Adding cookie "+cookie.getName());
                Cookie toAdd = new Cookie(config.getHost(), cookie.getName(), cookie.getValue());
                toAdd.setPath("/");
                state.addCookie(toAdd);
            }
        }
        
        int status = client.executeMethod(method);        

        return new Response(method.getResponseBodyAsString(), method.getResponseHeaders(), method.getStatusCode());             
   }

   /**
    * @return True if the state already contains a cookie with the given name; false otherwise.
    * @param name The name of the cookie to check.
    */
   private boolean cookieAlreadySet(String name)
   {
        Cookie[] c = state.getCookies();
        for(int i=0, n=c.length; i<n; i++)
        {
            if (name.equals(c[i].getName()))
            {
                return true;   
            }
        }
        return false;
   }


  /**
   * Request a HTTP URL.  The result of this request may update the session state
   * (e.g., if cookie are sent).
   * <p>
   * This method will become deprecated.  Use send() method instead.
   *
   * @param url The HTTP request to make, such as "http://127.0.0.1/hello.jsp" or
   * 			"http://127.0.0.1/hello.jsp?foo=baz".
   * @return The response from the server.
   *
   * @throws MalformedURLException Thrown if the supplied url is badly formed.
   * @throws IOException Thrown if there was any erors reading across the network.
   */
  public Response request(String url) throws MalformedURLException, IOException
  {
    Request request = this.newGetRequest(url); 
	return send(request);
  }




    /**
     * Set the HTTP version to send.
     *
     * @param version The HTTP version string, e.g., "HTTP/1.0" (the default).
     */
	public void setHTTPVersion(String version)
    {
      this.httpVersion = version;
    }


    /**
     * The HTTP version that is being sent with requests.
     *
     * @return The HTTP version sent with requests, such as "HTTP/1.0".
     */
	public String getHTTPVersion()
    {
      return this.httpVersion;
    }

	
	/**
	 * Construct a new request which will use the GET method.
	 * 
	 * @param	url			The URL to request.
	 * @return The request to be sent.
     * @throws MalformedURLException Thrown if the URL is bad. 
	 */
	public Request newGetRequest(String url) throws MalformedURLException
	{
		return new GetRequest(new URL(url), httpVersion);	
	}

	/**
	 * Construct a new request which will use the POST method.
	 * 
	 * @param	url			The URL to request.
	 * @return The request to be sent.
     * @throws MalformedURLException Thrown if the URL is bad.
	 */
	public Request newPostRequest(String url) throws MalformedURLException
	{
		return new PostRequest(new URL(url), httpVersion);	
	}

	
}