package com.dallaway.jsptest;

import java.net.URL;
import java.util.Hashtable;

import org.apache.commons.httpclient.methods.GetMethod;

/**
 * Implementation of Request where the method is GET.
 * 
 * @author $Author: richard $
 * @version	$Revision: 1.2 $ $Date: 2002/01/11 11:33:44 $
 */
public class GetRequest extends BaseRequest implements Request
{
	
	/** Buffer for building up the request string.*/
	private StringBuffer requestBuffer = new StringBuffer();

    /** True if the request has paremeters. */
	private boolean hasParams = false;
	
    /** The HTT version to use for this request. */
	private String httpVersion;
	
    /** The method used to making the GET request. */
    private GetMethod method;

    /**
     * Construct a new request.
     * 
     * @param url The url to request.
     * @param httpVersion The HTTP version to use.
     */
	public GetRequest(URL url, String httpVersion)
	{
		super(url);	
		this.httpVersion = httpVersion;
	
		requestBuffer.append(url.getFile());
		
		// Do we have any parameters?
		hasParams = url.getFile().indexOf("?") != -1;	
        

        method = new GetMethod(url.getPath());
        method.setQueryString(url.getQuery());        
        method.setHttp11(httpVersion.indexOf("1.1") != -1);
        setMethod(method);
        	
	}
	
	/**
     * @see com.dallaway.jsptest.Request#addParameter(String, String)
     */
	public void addParameter(String name, String value)
	{

        String qs = method.getQueryString();
        if (qs == null || "".equals(qs))
        {
            qs = name + "=" + urlEncode(value);
        }        
        else
        {
            qs = qs + "?" + name + "=" + urlEncode(value); 
        }
        method.setQueryString(qs);
        
        // The follow kept for compatability with JSP test release 5:
        
		requestBuffer.append( hasParams ? "&" : "?" );
		
		requestBuffer.append(name);
		requestBuffer.append("=");
		requestBuffer.append(urlEncode(value));
	
		hasParams = true;	
	}
	
	
    /**
     * @see Request#getRequestLine()
     * @deprecated No longer used internally.
     */
	public String getRequestLine()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("GET ");
		buf.append(requestBuffer.toString());
		buf.append(" ");
		buf.append(httpVersion);
		return buf.toString();
	}
	
    /** 
     * @see com.dallaway.jsptest.Request#getHeaders()
     * @deprecated Obsolete.
     */
	public Hashtable getHeaders()
	{
		return null;	
	}
	
    /** @see com.dallaway.jsptest.Request#getMessageBody() 
     * @deprecated Obsolete.
     */

	public String getMessageBody()
	{
		return null;
	}
	
	
	
	
}

