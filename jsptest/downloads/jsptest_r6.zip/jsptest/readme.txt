README.TXT

JSP TEST is a collection of Java classes to help you test JSPs automatically.
It is intended for use with a unit testing framework such as JUnit.

See http://www.dallaway.com/jsptest/ for details and the latest release.

This is release 6, 30 Dec 2002.  

This is a major change for JSP Test as all the internal HTTP client code 
has been replaced with calls to Apache's HTTP Client.  In effect JSP Test 
is just a wrapper for Apache's code. 

The reason for making this change is that Apache's code is a much better 
(more complete) implemnetation of the HTTP protocol.  However, in performing
the conversion I discovered a number of assumptions I'd made regarding HTTP headers
and cookies: these assumptions are fine for the kinds of testing I've been carrying
out, but it may confuse you if you're expecting more conformant behaviour.  It's
also left the code in a bit of a mess :-(

I've tried to preserve these assumptions to maintain the JSP Test
API: if you like the API, go with it; but if you want more sophisticated behaviour
I'd now recommend that you DO NOT use JSP TEST, but instead look
at Apache's HTTP client: http://jakarta.apache.org/commons/httpclient


See the apidoc/, Example1.txt and JSPTestTest.txt for example usage of the JSP TEST API.

Files:

src/		Java source code
jsptest.jar	Compiled classes.
test.war	The test pages used by JSPTestTest	
wwwtest/	Simple test pages, used by JSPTestTest.java
apidoc/		Java doc
lib/		Third party libraries used by jsptest
build.xml	The Ant build file.
readme.txt	This file.
howto.txt	How to use JSP Test.

This product includes code licensed from RSA Data Security.  Please
see the lib/jsseLICENCE.txt for details.

This product includes software developed by the Apache Software 
Foundation (http://www.apache.org/)

To run a test using JPSTest you need to include the JSSE libraries and
the Apache HTTP Client libraries. I.e.,

  java -cp jsptest.jar;lib/jsse.jar;lib/jcert.jar;lib/jnet.jar;lib/commons-httpclient.jar;lib/commons-logging.jar ...

To run JSPTestTest (the unit test for JSPTest), you also need junit.jar 
(version 3.7)

CHANGES

Release 6, 30 Dec 2002:

- Switched to using Apache's HTTP client in place of my own
  HTTP client code.

Release 5, 07 Jan 2002:

- Added support for POST requests
- Added howto.txt documentation on using JPSTest
- Better support for RFC 2616 (HTTP/1.1), including "100 Continue"


Release 4, 3 December 2001:

- Added HTTPS support using JSSE.


Release 3, 16 November 2001:

- Bug fix for testing pages on the default port (80).  Report by Vinoth Prabakaran.
- In preparation for JDK 1.4, the code has moved to using JUnit 3.7
- Addition of test.war to make it easier to set up the JSPTestTest requirements.
- build.xml upgraded to run with Ant 1.4.  General clean up of build process.




