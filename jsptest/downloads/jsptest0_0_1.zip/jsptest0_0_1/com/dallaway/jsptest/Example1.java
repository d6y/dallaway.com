package com.dallaway.jsptest;

/**
 * A simple example using the JSP TEST classes.

 * <p>
 * Run this class with a URL as an argument.

 * <p>
 * E.g., <tt>java com.dallaway.jsptest.Example1 http://127.0.0.1/foo.html</tt>
 *
 */
public class Example1
{

  public Example1()
  {
  }

  /**
   * Test that the request url exists.
   */
  public static void main(String[] args)
  {

    if (args.length != 1)
    {
      System.err.println("Usage: com.dallaway.jsptest.Example1 http://someurl/");
      System.exit(1);
    }

    // First create a sessions for maintaining cookies etc
    // You can think of this as your "client" for requests.
    Session s = new Session();

    // Next, request the page
    Response r = null;
    try
    {
      r = s.request(args[0]);
    }
    catch (Exception ex)
    {
      System.err.println("Failed to get page: "+ex);
      System.exit(1);
    }

    // We have the page, check the response:
    System.out.println("Status code: "+r.getStatusCode());

    // Was there a cookie called "foo"?  Making a request may well have
    // updated the sessions' list of cookies.
    String value = s.getCookieValue("foo");
    System.out.println("Cookie \"foo\" has a value of: "+value);

    // If you want all the cookies, go for:
    // Cookie[] cookies = s.getCookies();

    // And a bit of content:
    System.out.println("Content starts with: "+ r.getBody().substring(0, 500));

    System.out.println("Test complete");

  }
}