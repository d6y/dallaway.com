README.TXT

See jsptest.html for information.

Files:

com/		Source code
wwwtest/	Simple test pages, used by JSPTestTest.java
jsptest.jar	The test classes, ready to use
apidoc/		Java doc
jsptest.jpr	JBuilder 3.5 project file.  

Note: to rebuild the project you will need JUnit.jar or you can delete the JSPTestTest.java file.

You can get JUnit from: http://xprogramming.com/software.htm

You can find the latest version of jsp test at:
http://www.dallaway.com/jsptest


